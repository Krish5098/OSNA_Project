import pandas as pd

# Paths to the files
county_data_path = r"C:\Users\mithi\electionprediction\data\AK_l2_2022stats_county_pop_reg.csv"
turnout_data_path = r"C:\Users\mithi\electionprediction\data\number registere voter turnout.csv"
train_data_2016_path = r"C:\Users\mithi\electionprediction\data\voter_turnout2016P.csv"
train_data_2018_path = r"C:\Users\mithi\electionprediction\data\voter_turnout2018P.csv"
test_data_2020_path = r"C:\Users\mithi\electionprediction\data\voter_turnout2020P.csv"

# Load county data for 2022
df_county = pd.read_csv(county_data_path)

# Sum total registered voters for 2022
total_registered_2022 = df_county['total_reg'].sum()

# Load voter turnout data
df_turnout = pd.read_csv(turnout_data_path)

# Add total registered for 2022 to the turnout data
if 2022 not in df_turnout['Year'].values:
    new_row = {'Year': 2022, 'No. Registered': total_registered_2022, 'No.Voted': 0, '% Turnout': 0}
    df_turnout = pd.concat([df_turnout, pd.DataFrame([new_row])], ignore_index=True)
else:
    df_turnout.loc[df_turnout['Year'] == 2022, 'No. Registered'] = total_registered_2022

# Load and combine training data for previous years
data_train1 = pd.read_csv(train_data_2016_path)
data_train2 = pd.read_csv(train_data_2018_path)
data_train = pd.concat([data_train1, data_train2], ignore_index=True)

# Define party columns and calculate total votes
party_columns = ['Av', 'Cv', 'Dv', 'Ev', 'Gv', 'Lv', 'Nv', 'Ov', 'Pv', 'Rv', 'Uv']
data_train['Total_voted'] = data_train[party_columns].sum(axis=1)

# Calculate total voted for 2022
total_voted_2022 = data_train['Total_voted'].sum()

# Update No.Voted and calculate % Turnout for 2022
df_turnout.loc[df_turnout['Year'] == 2022, 'No.Voted'] = total_voted_2022
df_turnout.loc[df_turnout['Year'] == 2022, '% Turnout'] = (
    (total_voted_2022 / total_registered_2022) * 100
)

# Save the updated turnout data
output_path = r"C:\Users\mithi\electionprediction\data\number registere voter turnout_updated.csv"
df_turnout.to_csv(output_path, index=False)

# Output results
print(f"Updated turnout data saved to: {output_path}")
print(df_turnout[df_turnout['Year'] == 2022])
 