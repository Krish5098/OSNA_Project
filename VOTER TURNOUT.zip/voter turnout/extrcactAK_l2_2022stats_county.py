import pandas as pd

# File path
file_path = r"C:\Users\mithi\electionprediction\data\AK_l2_2022stats_county.csv"

# Load CSV data
data = pd.read_csv(file_path)

# Mapping of countyname to County
county_mapping = {
    "ALEUTIANS WEST": "Aleutians West Census Area",
    "ANCHORAGE": "Anchorage Municipality",
    "ALEUTIANS EAST": "Aleutians East Borough",
    "BETHEL": "Bethel Census Area",
    "BRISTOL BAY": "Bristol Bay Borough",
    "HAINES": "Haines Borough",
    "JUNEAU": "Juneau City and Borough",
    "NOME": "Nome Census Area",
    "CHUGACH": "Chugach Census Area",
    "COPPER RIVER": "Copper River Census Area",
    "PETERSBURG": "Petersburg Borough",
    "PRINCE OF WALES HYDER": "Prince of Wales-Hyder Census Area",
    "YUKON KOYUKUK": "Yukon-Koyukuk Census Area",
    "DENALI": "Denali Borough",
    "DILLINGHAM": "Dillingham Census Area",
    "FAIRBANKS NORTH STAR": "Fairbanks North Star Borough",
    "HOONAH ANGOON": "Hoonah-Angoon Census Area",
    "KENAI PENINSULA": "Kenai Peninsula Borough",
    "KETCHIKAN GATEWAY": "Ketchikan Gateway Borough",
    "KODIAK ISLAND": "Kodiak Island Borough",
    "KUSILVAK": "Kusilvak Census Area",
    "LAKE AND PENINSULA": "Lake and Peninsula Borough",
    "MATANUSKA SUSITNA": "Matanuska-Susitna Borough",
    "NORTH SLOPE": "North Slope Borough",
    "NORTHWEST ARCTIC": "Northwest Arctic Borough",
    "SITKA": "Sitka City and Borough",
    "SKAGWAY": "Skagway Municipality",
    "SOUTHEAST FAIRBANKS": "Southeast Fairbanks Census Area",
    "WRANGELL": "Wrangell City and Borough",
    "YAKUTAT": "Yakutat City and Borough",
}

# Rename countyname to County and update values
data.rename(columns={"countyname": "County"}, inplace=True)
data["County"] = data["County"].map(county_mapping)

# Select only the required columns (gender, county, and party-related columns)
selected_columns = [
    "County",
    "total_reg",
    "voters_gender_m",
    "voters_gender_f",
    "voters_gender_unknown",
    "party_rep",
    "party_npp",
    "party_dem",
    "party_ind",
    "party_lib",
    "party_glb",
    "party_cnt",
    "party_oth",
    "party_unk",
]
filtered_data = data[selected_columns]

# Save the filtered data to a new CSV file
output_path = r"C:\Users\mithi\electionprediction\data\Filtered_AK_l2_2022stats_county.csv"
filtered_data.to_csv(output_path, index=False)

print(f"Filtered file saved to {output_path}")
