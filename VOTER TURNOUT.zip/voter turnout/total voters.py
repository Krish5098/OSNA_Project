import pandas as pd

# Load the data
file_path = r"C:\Users\mithi\electionprediction\data\cleaned_ACS_data.csv"
data = pd.read_csv(file_path)

# Ensure the relevant columns are numeric (remove commas if needed)
age_columns = ['15 to 19 years', '20 to 24 years', '25 to 34 years', '35 to 44 years', '45 to 54 years',
               '55 to 59 years', '60 to 64 years', '65 to 74 years', '75 to 84 years', '85 years and over']



# Remove commas and convert age columns to numeric
for col in age_columns:
    data[col] = pd.to_numeric(data[col].str.replace(',', ''), errors='coerce')

# Ensure that the 'Male' and 'Female' columns are also numeric (remove commas if needed)
gender_columns = ['Male', 'Female']

# Remove commas and convert to numeric for Male and Female columns
for col in gender_columns:
    data[col] = pd.to_numeric(data[col].str.replace(',', ''), errors='coerce')

# Add the total gender column (Male + Female)
data['Total_population'] = data['Male'] + data['Female']
\

# Optionally, save the updated data
output_path = r'C:\Users\mithi\electionprediction\data\updated_with_totals.csv'
data.to_csv(output_path, index=False)
