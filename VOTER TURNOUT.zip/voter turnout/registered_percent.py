import pandas as pd

# Load the CSV data
file_path = r'C:\Users\mithi\electionprediction\data\AK_l2_2022stats_county_pop.csv'
data = pd.read_csv(file_path)

# Calculate Registered Percentage (based on total population)
data['Registered_Percentage'] = (data['total_reg'] / data['Total_population']) * 100

# Calculate number of male and female registered voters
data['Male_voters_percentage'] = (data['voters_gender_m'] / data['Male']) * 100
data['Female_voters_Percentage'] = (data['voters_gender_f'] / data['Female']) * 100

# Save the updated data to a new CSV file
output_path = r"C:\Users\mithi\electionprediction\data\AK_l2_2022stats_county_pop_reg.csv"
data.to_csv(output_path, index=False)

print(f"Updated data saved to: {output_path}")
