import pandas as pd

# Define the file paths for the input CSV files
file_paths = [
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport 2020g.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2016G.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2016P.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2018G.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2018P.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2020P.csv"
]

# Process each file separately
for file_path in file_paths:
    # Load the CSV data
    data = pd.read_csv(file_path)

    # Split the data into two parts based on 'VOTED_OR_TOTALS'
    data_voted = data[data['VOTED_OR_TOTALS'] == 'VOTED']
    data_total = data[data['VOTED_OR_TOTALS'] == 'TOTAL']

    # Rename the columns for the 'VOTED' data
    data_voted.rename(columns={
        'TOTAL': 'TOTAL_voted',
        'A': 'Av',
        'C': 'Cv',
        'D': 'Dv',
        'E': 'Ev',
        'G': 'Gv',
        'H': 'Hv',
        'K': 'Kv',
        'L': 'Lv',
        'N': 'Nv',
        'O': 'Ov',
        'P': 'Pv',
        'R': 'Rv',
        'U': 'Uv',
        'V': 'Vv',
        'W': 'Wv'
    }, inplace=True)

    # Drop the '%' column from both dataframes
    data_voted.drop(columns=['%'], inplace=True)
    data_total.drop(columns=['%'], inplace=True)

    # Define the output paths for the split files
    output_path_voted = file_path.replace(".csv", "_voted.csv")
    output_path_total = file_path.replace(".csv", "_total.csv")

    # Save each part to a new CSV file
    data_voted.to_csv(output_path_voted, index=False)
    data_total.to_csv(output_path_total, index=False)

    # Print the paths where the files were saved
    print(f"Data split, columns renamed, and saved to:\n{output_path_voted}\n{output_path_total}")
