import pandas as pd
import datetime

# Load the original CSV data
file_path = r"C:\Users\mithi\electionprediction\data\age_gender_ethi_data.csv"
data = pd.read_csv(file_path)

# List of ethnicity groups to exclude
ethnicity_groups = ['eth1_eur', 'eth1_hisp', 'eth1_aa', 'eth1_esa', 'eth1_oth', 'eth1_unk',
                    'eth2_euro', 'eth2_64', 'eth2_34', 'eth2_10', 'eth2_93', 'eth2_81', 'eth2_85',
                    'eth2_14', 'eth2_30', 'eth2_12', 'eth2_21', 'eth2_83', 'eth2_23', 'eth2_15', 'eth2_unk']

# Drop the ethnicity columns
data.drop(columns=ethnicity_groups, inplace=True)

# List of age groups to sum
age_groups = ['age_18_19', 'age_20_24', 'age_25_29', 'age_30_34', 'age_35_44',
              'age_45_54', 'age_55_64', 'age_65_74', 'age_75_84', 'age_85over']

# Group by 'County' and sum the age groups, also include 'total_reg' (total registered voters)
county_age_sum = data.groupby('County')[age_groups + ['total_reg']].sum()

# Optionally, if you want to add a column for 'Total_Age' per county
county_age_sum['Total_Age_voted'] = county_age_sum[age_groups].sum(axis=1)

# Save the updated data to a new CSV file
output_path = f'C:\\Users\\mithi\\electionprediction\\data\\county_age_sum_with_total_reg.csv'
county_age_sum.to_csv(output_path, index=True)

# Load the updated data from the saved CSV file
new_data = pd.read_csv(output_path)

# Print the first few rows of the updated data
print(new_data.head())
