import pandas as pd
import os
import matplotlib.pyplot as plt

# Path to the directory containing the CSV files
data_directory = r'C:\Users\mithi\electionprediction\csv_outputs'

# Iterate over all CSV files in the directory
for file_name in os.listdir(data_directory):
    if file_name.endswith('.csv'):
        file_path = os.path.join(data_directory, file_name)

        print(f"\nProcessing file: {file_name}")

        # Load the CSV file
        data = pd.read_csv(file_path)

        # Display DataFrame and its columns
        print("Loaded Data:")
        print(data.head())
        print("\nColumns in the DataFrame:")
        print(data.columns)

        # Ensure columns used in calculations exist
        required_columns = ['HOUSE', 'ACCEPT_FULL', 'ACCEPT_PARTIAL', 'REJECT']
        if not all(col in data.columns for col in required_columns):
            print(f"Skipping {file_name}: Required columns are missing.")
            continue

        # Group data by 'HOUSE' and sum the 'ACCEPTED FULL' column
        accepted_full_sum_by_house = data.groupby("HOUSE")["ACCEPT_FULL"].sum()
        print("\nSum of 'ACCEPTED FULL' by HOUSE:")
        print(accepted_full_sum_by_house)

        # Define columns to sum for grouped calculations
        columns_to_sum = ['ACCEPT_FULL', 'ACCEPT_PARTIAL', 'REJECT']

        # Group by 'HOUSE' and calculate the sum for specified columns
        grouped_sum = data.groupby('HOUSE')[columns_to_sum].sum()
        print("\nGrouped Sum by HOUSE:")
        print(grouped_sum)

        # Add a 'Total Votes' column (sum across specified columns)
        grouped_sum['Total Votes'] = grouped_sum.sum(axis=1)
        print("\nGrouped Sum with 'Total Votes':")
        print(grouped_sum)

        # Calculate 'Accepted Percentage'
        grouped_sum['Accepted Percentage'] = (
                                                     ((grouped_sum['ACCEPT_FULL'] + grouped_sum['ACCEPT_PARTIAL']) -
                                                      grouped_sum['REJECT'])
                                                     / grouped_sum['Total Votes']
                                             ) * 100

        print("\nGrouped Sum with 'Accepted Percentage':")
        print(grouped_sum)

        # Save the processed data to a new CSV file
        output_file = os.path.join(data_directory, f"{os.path.splitext(file_name)[0]}_processed.csv")
        grouped_sum.to_csv(output_file)

        print(f"Processed data has been saved to {output_file}")

        # Plotting the 'Accepted Percentage' trend across 'HOUSE'
        plt.figure(figsize=(10, 6))
        plt.plot(grouped_sum.index, grouped_sum['Accepted Percentage'], marker='o', color='green',
                 label='Accepted Percentage')

        # Title and labels for Accepted Percentage
        plt.title(f'ACCEPTED PERCENTAGE: {file_name}')
        plt.xlabel('HOUSE')
        plt.ylabel('Accepted Percentage (%)')
        plt.xticks(rotation=45)
        plt.legend(title='Accepted Percentage')

        # Display the plot for Accepted Percentage
        plt.tight_layout()
        plt.show()
