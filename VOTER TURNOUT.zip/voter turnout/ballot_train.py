import ballot_total_acceptence
# Calculate Total Acceptance Rate
# Total Acceptance Rate = (Total Accepted Votes / (Total Accepted + Total Rejected)) * 100
def calculate_acceptance_rate(data):
    total_accepted = data['TOTAL_ACCEPTED'].sum()
    total_rejected = data['REJECT'].sum()
    total_votes = total_accepted + total_rejected
    acceptance_rate = (total_accepted / total_votes) * 100 if total_votes > 0 else 0
    return acceptance_rate

# Calculate acceptance rate for the combined data
total_acceptance_rate = calculate_acceptance_rate(combined_data)
print(f"Total Acceptance Rate (All Data Combined): {total_acceptance_rate:.2f}%")

# Calculate Predicted Total Acceptance Rate for all houses combined
# Sum predicted accepted votes and calculate the predicted acceptance rate
def calculate_predicted_acceptance_rate(X_test, y_pred, data):
    # Map predictions back to original data
    predicted_total_accepted = pd.DataFrame({'HOUSE': X_test['HOUSE'], 'PREDICTED_ACCEPTED': y_pred})
    predicted_total = predicted_total_accepted.groupby('HOUSE')['PREDICTED_ACCEPTED'].sum().sum()
    actual_rejected = data['REJECT'].sum()
    predicted_acceptance_rate = (predicted_total / (predicted_total + actual_rejected)) * 100 if (predicted_total + actual_rejected) > 0 else 0
    return predicted_acceptance_rate

# Calculate the predicted acceptance rate for combined data
predicted_acceptance_rate = calculate_predicted_acceptance_rate(X_test, y_pred, combined_data)
print(f"Predicted Total Acceptance Rate (All Houses Combined): {predicted_acceptance_rate:.2f}%")
