import os
import pdfplumber
import pandas as pd
import re


def extract_raw_data(pdf_path):
    """Extract raw text data from a PDF."""
    with pdfplumber.open(pdf_path) as pdf:
        raw_data = []
        for page in pdf.pages:
            # Extract text from each page
            text = page.extract_text()
            if text:
                # Split text into lines
                lines = text.split('\n')
                raw_data.extend(lines)
    return raw_data


def tabulate_data(raw_data):
    """Parse raw data and structure it into a tabulated format."""
    tabulated_data = []
    current_house = None

    for line in raw_data:
        # Identify house number
        if "HOUSE:" in line:
            current_house = line.split(":")[1].strip()  # Extract house number
            continue
        # Match voting method statistics
        match = re.search(
            r'(?P<method>INPERSON|MAIL|ONLINE|FAX|FWAB|EARLY|QUESTIONED)\s+'
            r'(?P<accept_full>\d+)\s+(?P<accept_partial>\d+)\s+(?P<reject>\d+)\s+'
            r'(?P<apps_rcvd>\d+)\s+(?P<ballot_sent>\d+)\s+(?P<ballot_rcvd>\d+)',
            line
        )
        if match and current_house and current_house != "99":  # Exclude house 99
            # Create a data entry
            data_entry = {
                'ACCEPT_FULL': int(match.group('accept_full')),
                'ACCEPT_PARTIAL': int(match.group('accept_partial')),
                'REJECT': int(match.group('reject')),
                'APPS_RCVD': int(match.group('apps_rcvd')),
                'BALLOT_SENT': int(match.group('ballot_sent')),
                'BALLOT_RCVD': int(match.group('ballot_rcvd')),
                'HOUSE': current_house,  # Add house number
                'VOTING_METHOD': match.group('method')  # Add voting method
            }
            tabulated_data.append(data_entry)

    return tabulated_data


def clean_data(df):
    """Clean the DataFrame by removing missing values and duplicates."""
    df.dropna(inplace=True)
    df.drop_duplicates(inplace=True)
    df['HOUSE'] = df['HOUSE'].astype(str)  # Ensure HOUSE is string
    return df


def process_pdfs(pdf_paths, output_folder):
    """Process multiple PDF files and save their data as CSV files."""
    for pdf_path in pdf_paths:
        try:
            # Extract raw data from the PDF
            raw_data = extract_raw_data(pdf_path)

            # Parse and structure the data
            tabulated_data = tabulate_data(raw_data)
            df = pd.DataFrame(tabulated_data)

            # Clean the data
            df = clean_data(df)

            # Generate output file path
            pdf_name = os.path.splitext(os.path.basename(pdf_path))[0]
            output_csv_path = os.path.join(output_folder, f"{pdf_name}.csv")

            # Save the cleaned data to a CSV file
            df.to_csv(output_csv_path, index=False)
            print(f"Processed {pdf_path} and saved to {output_csv_path}")
        except Exception as e:
            print(f"Failed to process {pdf_path}: {e}")


# Main Execution
# Define the list of PDF files
pdf_files = [
    r'C:\Users\mithi\electionprediction\Combined Ballot Count Report_9.2.2022.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\CombinedBallotCountReport_Server2020G.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\CombinedBallotCountReport_6242022FINAL2020P.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\Combined Ballot Count Report_9.2.2022G.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\2018PrimAbsenteeQuestionBallotStats2018P.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\2016PrimAbsenteeQuestionBallotStats2016P.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\2016GenCombineFilingReport2016G.pdf',
    r'C:\Users\mithi\electionprediction\voter history by age\18GenCombineFilingReport2018G.pdf'
]

# Specify the output folder for the CSV files
output_folder = r'C:\Users\mithi\electionprediction\csv_outputs'
os.makedirs(output_folder, exist_ok=True)  # Create the folder if it doesn't exist

# Process all PDF files
process_pdfs(pdf_files, output_folder)
