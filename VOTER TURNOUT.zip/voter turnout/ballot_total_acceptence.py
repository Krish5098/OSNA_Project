import pandas as pd
import numpy as np

# File paths
file_paths = [
    r"C:\Users\mithi\electionprediction\csv_outputs\18GenCombineFilingReport2018G_processed.csv",
    r"C:\Users\mithi\electionprediction\csv_outputs\2016GenCombineFilingReport2016G_processed.csv",
    r"C:\Users\mithi\electionprediction\csv_outputs\CombinedBallotCountReport_Server2020G_processed.csv"
]

# Step 1: Load Data
data_2018 = pd.read_csv(file_paths[0])
data_2016 = pd.read_csv(file_paths[1])
data_2020 = pd.read_csv(file_paths[2])

# Step 2: Inspect Data
print("2018 Data Columns:", data_2018.columns)
print("2016 Data Columns:", data_2016.columns)
print("2020 Data Columns:", data_2020.columns)

# Step 3: Clean Data
# Remove rows with missing values and drop duplicates
def clean_data(data):
    data = data.dropna()
    data = data.drop_duplicates()
    return data

data_2018_clean = clean_data(data_2018)
data_2016_clean = clean_data(data_2016)
data_2020_clean = clean_data(data_2020)

# Step 4: Feature Selection (Ensure we're using relevant columns for Total Accepted Votes)
# Assuming columns similar to 'ACCEPTED FULL', 'ACCEPTED PARTIAL', and 'REJECT' are available in each dataset
columns_to_use = ['ACCEPT_FULL', 'ACCEPT_PARTIAL', 'REJECT']

# Calculate Total Accepted Votes by adding Full and Partial Accepted Votes
def calculate_total_accepted(data, columns=columns_to_use):
    data['TOTAL_ACCEPTED'] = data['ACCEPT_FULL'] + data['ACCEPT_PARTIAL']
    return data

# Apply calculation on each dataset
data_2018_clean = calculate_total_accepted(data_2018_clean)
data_2016_clean = calculate_total_accepted(data_2016_clean)
data_2020_clean = calculate_total_accepted(data_2020_clean)

# Step 5: Combine Data (if needed, combining by year or other groupings)
combined_data = pd.concat([data_2018_clean, data_2016_clean, data_2020_clean], axis=0)

# Step 6: Model Development (Optional)
# We can create a simple model if there's a need to predict Total Accepted Votes from other features
from sklearn.linear_model import LinearRegression

# Feature Engineering - Let's assume we have 'HOUSE' as a feature and 'TOTAL_ACCEPTED' as the target
X = combined_data[['HOUSE']]  # Features (add more if needed)
y = combined_data['TOTAL_ACCEPTED']  # Target variable

# Train-Test Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict on test data
y_pred = model.predict(X_test)

# Step 7: Evaluation
from sklearn.metrics import mean_squared_error, r2_score
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"R-squared: {r2}")

# Step 8: Save processed data with Total Accepted Votes
combined_data.to_csv(r'C:\Users\mithi\electionprediction\csv_outputs\combined_data_with_total_accepted.csv', index=False)

print("\nProcessed data with Total Accepted Votes saved.")
# Calculate Total Acceptance Rate
# Total Acceptance Rate = (Total Accepted Votes / (Total Accepted + Total Rejected)) * 100
def calculate_acceptance_rate(data):
    total_accepted = data['TOTAL_ACCEPTED'].sum()
    total_rejected = data['REJECT'].sum()
    total_votes = total_accepted + total_rejected
    acceptance_rate = (total_accepted / total_votes) * 100 if total_votes > 0 else 0
    return acceptance_rate

# Calculate acceptance rate for the combined data
total_acceptance_rate = calculate_acceptance_rate(combined_data)
print(f"Total Acceptance Rate (All Data Combined): {total_acceptance_rate:.2f}%")

# Calculate Predicted Total Acceptance Rate for all houses combined
# Sum predicted accepted votes and calculate the predicted acceptance rate
def calculate_predicted_acceptance_rate(X_test, y_pred, data):
    # Map predictions back to original data
    predicted_total_accepted = pd.DataFrame({'HOUSE': X_test['HOUSE'], 'PREDICTED_ACCEPTED': y_pred})
    predicted_total = predicted_total_accepted.groupby('HOUSE')['PREDICTED_ACCEPTED'].sum().sum()
    actual_rejected = data['REJECT'].sum()
    predicted_acceptance_rate = (predicted_total / (predicted_total + actual_rejected)) * 100 if (predicted_total + actual_rejected) > 0 else 0
    return predicted_acceptance_rate

# Calculate the predicted acceptance rate for combined data
predicted_acceptance_rate = calculate_predicted_acceptance_rate(X_test, y_pred, combined_data)
print(f"Predicted Total Acceptance Rate (All Houses Combined): {predicted_acceptance_rate:.2f}%")

