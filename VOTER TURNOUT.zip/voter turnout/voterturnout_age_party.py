import pandas as pd

# List of file paths for the combined datasets
file_paths = [
   r"C:\Users\mithi\electionprediction\data\combined_VoterHistoryByAgeReport2016G.csv",
    #r"C:\Users\mithi\electionprediction\data\combined_VoterHistoryByAgeReport2016P.csv",
    r"C:\Users\mithi\electionprediction\data\combined_VoterHistoryByAgeReport2018G.csv",
   # r"C:\Users\mithi\electionprediction\data\combined_VoterHistoryByAgeReport2018P.csv",
    r"C:\Users\mithi\electionprediction\data\combined_VoterHistoryByAgeReport2020G.csv",
   # r"C:\Users\mithi\electionprediction\data\combined_VoterHistoryByAgeReport2020P.csv"
]

# List of output paths for the voter turnout CSV files
output_paths = [
    r"C:\Users\mithi\electionprediction\data\voter_turnout2016G.csv",
    #r"C:\Users\mithi\electionprediction\data\voter_turnout2016P.csv",
    r"C:\Users\mithi\electionprediction\data\voter_turnout2018G.csv",
   # r"C:\Users\mithi\electionprediction\data\voter_turnout2018P.csv",
    r"C:\Users\mithi\electionprediction\data\voter_turnout2020G.csv",
   # r"C:\Users\mithi\electionprediction\data\voter_turnout2020P.csv"
]

# Party columns for calculating voter turnout for each party (full list for reference)
party_columns = ['Av', 'Cv', 'Dv', 'Ev', 'Gv', 'Hv', 'Kv', 'Lv', 'Nv', 'Ov', 'Pv', 'Rv', 'Uv', 'Vv', 'Wv']

# Iterate over each file path and process the corresponding data
for file_path, output_path in zip(file_paths, output_paths):
    # Load the data into a DataFrame
    data = pd.read_csv(file_path)

    # Calculate the voter turnout for each age group
    data['Voter_Turnout_Age_Group'] = (data['TOTAL_voted'] / data['TOTAL']) * 100

    # Get the party columns available in the current dataset
    available_party_columns = [party for party in party_columns if party in data.columns]

    # Calculate the voter turnout for each available party in the dataset
    for party in available_party_columns:
        data[f'Voter_Turnout_{party}'] = (data[party] / data['TOTAL_voted']) * 100

    # Save the updated data with voter turnout percentages to a new CSV file
    data.to_csv(output_path, index=False)

    # Print the path where the data with voter turnout was saved
    print(f"Voter turnout data saved to: {output_path}")
    import matplotlib.pyplot as plt
    import seaborn as sns


    # Function to visualize voter turnout
    def visualize_voter_turnout(data, output_path, year, election_type):
    

        # Line plot for voter turnout by parties
        plt.figure(figsize=(14, 8))
        for party in [col for col in data.columns if
                      col.startswith('Voter_Turnout_') and col != 'Voter_Turnout_Age_Group']:
            plt.plot(data['AGE_GROUP'], data[party], marker='o', label=party.replace('Voter_Turnout_', ''))
        plt.title(f'Voter Turnout by Party ({year} {election_type})', fontsize=16)
        plt.xlabel('Age Group', fontsize=12)
        plt.ylabel('Voter Turnout (%)', fontsize=12)
        plt.xticks(rotation=45, ha='right')
        plt.legend(title='Party', bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.savefig(output_path.replace('.csv', '_party_turnout.png'))
        plt.show()


    # Visualize each processed dataset
    for output_path, year_type in zip(output_paths, ['2016P', '2018P', '2020P']):
        try:
            # Reload the processed data
            processed_data = pd.read_csv(output_path)
            year, election_type = year_type[:4], year_type[4:]

            # Call the visualization function
            visualize_voter_turnout(processed_data, output_path, year, election_type)
        except Exception as e:
            print(f"Error visualizing data for {output_path}: {e}")

