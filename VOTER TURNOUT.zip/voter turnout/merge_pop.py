import pandas as pd

# Load the original CSV data (file_path2)
file_path2 = output_path = r"C:\Users\mithi\electionprediction\data\Filtered_AK_l2_2022stats_county.csv"
data2 = pd.read_csv(file_path2)

# Load the data with total population (file_path3)
file_path3 = r'C:\Users\mithi\electionprediction\data\updated_with_totals.csv'
data3 = pd.read_csv(file_path3)

# Ensure the common key column (e.g., 'County') exists in both dataframes
# Merge data2 with the Total_Population column from data3
merged_data = pd.merge(data2, data3[['County', 'Total_population','Male','Female']], on='County', how='left')



# Optionally, save the updated data to a new file
output_path = r'C:\Users\mithi\electionprediction\data\AK_l2_2022stats_county_pop.csv'
merged_data.to_csv(output_path, index=False)

# Display the first few rows of the merged dataframe
print(merged_data.head())
