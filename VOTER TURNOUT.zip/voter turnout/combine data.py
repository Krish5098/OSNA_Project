import pandas as pd
import os

# List of files for both '_voted' and '_total'
file_paths_voted = [
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport 2020g_voted.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2016G_voted.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2016P_voted.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2018G_voted.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2018P_voted.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2020P_voted.csv"
]

file_paths_total = [
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2020g_total.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2016G_total.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2016P_total.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2018G_total.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2018P_total.csv",
    r"C:\Users\mithi\electionprediction\IndividualFiles\VoterHistoryByAgeReport2020P_total.csv"
]

# Iterate over each pair of voted and total files
for voted_file, total_file in zip(file_paths_voted, file_paths_total):
    # Extract the base name of the file (before '_voted' or '_total')
    base_name_voted = os.path.splitext(os.path.basename(voted_file))[0].replace("_voted", "")
    base_name_total = os.path.splitext(os.path.basename(total_file))[0].replace("_total", "")

    # Check if the base names match
    if base_name_voted == base_name_total:
        # Load the CSV data
        data_voted = pd.read_csv(voted_file)
        data_total = pd.read_csv(total_file)

        # Merge the two DataFrames based on the 'AGE_GROUP' column
        merged_data = pd.merge(data_voted, data_total, on='AGE_GROUP', how='outer', suffixes=('_voted', '_total'))

        # Drop the 'VOTED_OR_TOTALS' column
        merged_data.drop(columns=['VOTED_OR_TOTALS_voted', 'VOTED_OR_TOTALS_total'], inplace=True, errors='ignore')

        # Define the output path for the merged file
        output_combined_path = os.path.join(r"C:\Users\mithi\electionprediction\data",
                                            f"combined_{base_name_voted}.csv")

        # Save the merged data to a new CSV file
        merged_data.to_csv(output_combined_path, index=False)

        # Print the path where the combined file was saved
        print(f"Combined data saved to: {output_combined_path}")
    else:
        print(f"Base names do not match for: {voted_file} and {total_file}, skipping merge.")
